// WebDL Queue Extension (MV3)
// - Adds context menu items to enqueue URLs as Single or Playlist.
// - Persists queue + log in chrome.storage.local.
// - Runs/Stops by calling the existing local server: http://localhost:8787
// - Streams SSE output from /api/run and stores log/progress.

const API_BASE = "http://localhost:8787";

const MENU_SINGLE = "webdl_add_single";
const MENU_PLAYLIST = "webdl_add_playlist";

const DEFAULT_STATE = {
  mode: "1", // 1 mp3, 2 flac, 3 mp4
  urlsCollapsed: false,
  jobs: [], // {url, pl, folder}
  running: false,
  progressPercent: 0,
  progressText: "Progress: —",
  log: "",
  meta: ""
};

/** @type {Set<chrome.runtime.Port>} */
const ports = new Set();

// Used to cancel an active /api/run stream.
let runAbort = null;

chrome.runtime.onInstalled.addListener(async () => {
  // Context menus
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: MENU_SINGLE,
      title: "Add to WebDL Queue (Single)",
      contexts: ["link", "selection", "page"]
    });
    chrome.contextMenus.create({
      id: MENU_PLAYLIST,
      title: "Add to WebDL Queue (Playlist)",
      contexts: ["link", "selection", "page"]
    });
  });

  // Init state if missing
  const st = await getState();
  await setState({ ...DEFAULT_STATE, ...st });
});

chrome.runtime.onConnect.addListener((port) => {
  ports.add(port);
  port.onDisconnect.addListener(() => ports.delete(port));

  // Immediately send current state
  getState().then((st) => {
    try { port.postMessage({ type: "state", state: st }); } catch {}
  });
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  const pl = (info.menuItemId === MENU_PLAYLIST) ? "1" : "2";

  const raw = (info.linkUrl && info.linkUrl.trim())
    || (info.selectionText && info.selectionText.trim())
    || (info.pageUrl && info.pageUrl.trim())
    || "";

  if (!raw) return;

  await addJob({ url: raw, pl, folder: "" });
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type === "_patchLog") {
    (async () => {
      const st = await getState();
      await patchState({ log: capLog((st.log || "") + String(msg.text || "")) });
    })();
    sendResponse({ ok: true });
    return true;
  }
  (async () => {
    switch (msg?.type) {
      case "getState": {
        sendResponse({ ok: true, state: await getState() });
        return;
      }
      case "setMode": {
        await patchState({ mode: String(msg.mode || "1") });
        sendResponse({ ok: true });
        return;
      }
      case "toggleUrls": {
        const st = await getState();
        await patchState({ urlsCollapsed: !st.urlsCollapsed });
        sendResponse({ ok: true });
        return;
      }
      case "addJob": {
        // Allow an empty URL only when explicitly requested (for manual entry via the popup).
        const allowEmpty = !!msg.allowEmpty;
        const raw = String(msg.url ?? "");
        const url = allowEmpty ? raw : raw.trim();
        const pl = (String(msg.pl || "2") === "1") ? "1" : "2";
        const folder = String(msg.folder || "");
        if (!url && !allowEmpty) { sendResponse({ ok: false, error: "No URL" }); return; }
        await addJob({ url, pl, folder });
        sendResponse({ ok: true });
        return;
      }
case "updateJob": {
        const idx = Number(msg.index);
        const patch = msg.patch || {};
        await updateJob(idx, patch);
        sendResponse({ ok: true });
        return;
      }
      case "removeJob": {
        await removeJob(Number(msg.index));
        sendResponse({ ok: true });
        return;
      }
      case "clearJobs": {
        await patchState({ jobs: [] });
        sendResponse({ ok: true });
        return;
      }
      case "clearLog": {
        await patchState({ log: "", meta: "", progressPercent: 0, progressText: "Progress: —" });
        sendResponse({ ok: true });
        return;
      }
      case "status": {
        sendResponse({ ok: true, status: await fetchStatusSafe() });
        return;
      }
      case "run": {
        const result = await startRun();
        sendResponse({ ok: result.ok, error: result.error || null });
        return;
      }
      case "stop": {
        const result = await stopRun();
        sendResponse({ ok: result.ok, error: result.error || null });
        return;
      }
      default:
        sendResponse({ ok: false, error: "Unknown message" });
        return;
    }
  })().catch((err) => {
    sendResponse({ ok: false, error: String(err?.message || err) });
  });

  // Keep channel open for async response
  return true;
});

async function getState() {
  const res = await chrome.storage.local.get(["state"]);
  return res.state || { ...DEFAULT_STATE };
}

async function setState(state) {
  await chrome.storage.local.set({ state });
  broadcast(state);
}

async function patchState(patch) {
  const st = await getState();
  const next = { ...st, ...patch };
  await chrome.storage.local.set({ state: next });
  broadcast(next);
}

function broadcast(state) {
  for (const p of ports) {
    try { p.postMessage({ type: "state", state }); } catch {}
  }
}

async function addJob(job) {
  const st = await getState();
  const jobs = Array.isArray(st.jobs) ? st.jobs.slice() : [];
  jobs.push({
    url: String(job.url || "").trim(),
    pl: (String(job.pl || "2") === "1") ? "1" : "2",
    folder: String(job.folder || ""),
    selected: !!job.selected
  });
  await patchState({ jobs });
}

async function updateJob(index, patch) {
  const st = await getState();
  const jobs = Array.isArray(st.jobs) ? st.jobs.slice() : [];
  if (!Number.isFinite(index) || index < 0 || index >= jobs.length) return;

  const next = { ...jobs[index] };
  if (patch.url !== undefined) next.url = String(patch.url);
  if (patch.pl !== undefined) next.pl = (String(patch.pl) === "1") ? "1" : "2";
  if (patch.folder !== undefined) next.folder = String(patch.folder);
  if (patch.selected !== undefined) next.selected = !!patch.selected;

  jobs[index] = next;
  await patchState({ jobs });
}

async function removeJob(index) {
  const st = await getState();
  const jobs = Array.isArray(st.jobs) ? st.jobs.slice() : [];
  if (!Number.isFinite(index) || index < 0 || index >= jobs.length) return;
  jobs.splice(index, 1);
  await patchState({ jobs });
}

async function fetchStatusSafe() {
  try {
    const r = await fetch(`${API_BASE}/api/status`, { method: "GET" });
    if (!r.ok) return { online: false, running: false };
    const j = await r.json();
    return { online: true, running: !!j.running };
  } catch {
    return { online: false, running: false };
  }
}

function capLog(s, max = 20000) {
  s = String(s || "");
  if (s.length <= max) return s;
  return s.slice(s.length - max);
}

// Replicates the front-end's progress parsing (simplified).
function applyOutputChunk(state, raw) {
  let log = state.log || "";
  let progressPercent = state.progressPercent || 0;
  let progressText = state.progressText || "Progress: —";

  const parts = String(raw || "").split(/\r|\n/);
  for (const line of parts) {
    const s = (line || "").trim();
    if (!s) continue;

    const m = s.match(/^\[download\]\s+(\d+(?:\.\d+)?)%/i);
    if (m) {
      const pct = Math.floor(parseFloat(m[1]));
      if (Number.isFinite(pct)) {
        progressPercent = pct;

        const sm = s.match(/\bat\s+([0-9.]+\w+\/s)\b/i);
        const em = s.match(/\bETA\s+(\S+)\b/i);
        const speed = sm ? sm[1] : "";
        const eta = em ? em[1] : "";
        let extra = "";
        if (speed) extra += ` | ${speed}`;
        if (eta) extra += ` | ETA ${eta}`;
        progressText = `Progress: ${pct}%${extra}`;
      }
      continue;
    }

    log += s + "\n";
  }

  return {
    log: capLog(log),
    progressPercent,
    progressText
  };
}

async function startRun() {
  const st = await getState();
  if (st.running) return { ok: false, error: "Already running." };

  const jobs = (st.jobs || [])
    .map(j => ({ url: String(j.url || "").trim(), pl: (String(j.pl || "2") === "1") ? "1" : "2", folder: String(j.folder || "").trim() }))
    .filter(j => j.url.length > 0);

  if (!jobs.length) return { ok: false, error: "No URLs." };

  // Mark running + reset progress
  await patchState({
    running: true,
    progressPercent: 0,
    progressText: "Progress: —",
    meta: "",
    log: capLog((st.log || "") + `\n=== Starting (${modeLabel(st.mode)}) ===\n`)
  });

  const controller = new AbortController();
  runAbort = controller;

  try {
    const resp = await fetch(`${API_BASE}/api/run`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ mode: String(st.mode || "1"), jobs }),
      signal: controller.signal
    });

    if (!resp.ok) {
      const txt = await safeText(resp);
      await patchState({
        running: false,
        log: capLog((await getState()).log + `\n=== Failed to start (${resp.status}) ===\n${txt}\n`)
      });
      runAbort = null;
      return { ok: false, error: `Server error ${resp.status}` };
    }

    // Parse SSE stream
    const reader = resp.body?.getReader();
    if (!reader) throw new Error("No stream reader");

    const decoder = new TextDecoder("utf-8");
    let buffer = "";

    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });

      // SSE events are separated by blank line
      let idx;
      while ((idx = buffer.indexOf("\n\n")) !== -1) {
        const rawEvent = buffer.slice(0, idx);
        buffer = buffer.slice(idx + 2);
        await handleSseEvent(rawEvent);
      }
    }

    // If stream ended without a done event
    const st2 = await getState();
    if (st2.running) {
      await patchState({
        running: false,
        log: capLog(st2.log + "\n=== Done ===\n"),
        progressPercent: Math.max(st2.progressPercent || 0, 100),
        progressText: "Progress: complete"
      });
    }

    runAbort = null;
    return { ok: true };
  } catch (err) {
    const msg = String(err?.message || err);
    const st3 = await getState();
    await patchState({
      running: false,
      log: capLog(st3.log + `\n=== Run aborted / error ===\n${msg}\n`)
    });
    runAbort = null;
    return { ok: false, error: msg };
  }
}

async function handleSseEvent(rawEvent) {
  // rawEvent is a block of lines:
  // event: out
  // data: {"text":"..."}
  const lines = rawEvent.split(/\n/);
  let type = "message";
  let dataLine = "";

  for (const line of lines) {
    if (line.startsWith("event:")) type = line.slice(6).trim();
    if (line.startsWith("data:")) dataLine += line.slice(5).trim();
  }

  let data = null;
  try { data = dataLine ? JSON.parse(dataLine) : null; } catch { data = { text: dataLine }; }

  const st = await getState();

  if (type === "meta") {
    await patchState({ meta: data?.logFile ? `Log file: ${data.logFile}` : "" });
    return;
  }

  if (type === "out" || type === "err") {
    const applied = applyOutputChunk(st, data?.text || "");
    await patchState({
      log: applied.log,
      progressPercent: applied.progressPercent,
      progressText: applied.progressText
    });
    return;
  }

  if (type === "done") {
    const code = data?.code;
    await patchState({
      running: false,
      log: capLog(st.log + `\n=== Done (exit ${code}) ===\n`),
      progressPercent: 100,
      progressText: "Progress: complete"
    });
    return;
  }
}

async function stopRun() {
  try {
    // Ask server to stop.
    await fetch(`${API_BASE}/api/stop`, { method: "POST" });
  } catch {
    // ignore
  }

  // Also abort our stream read.
  if (runAbort) {
    try { runAbort.abort(); } catch {}
    runAbort = null;
  }

  const st = await getState();
  await patchState({
    running: false,
    log: capLog(st.log + "\n=== Stop requested ===\n")
  });

  return { ok: true };
}

function modeLabel(mode) {
  switch (String(mode)) {
    case "1": return "MP3 Audio";
    case "2": return "FLAC Audio";
    case "3": return "MP4 Video";
    default: return "Unknown";
  }
}

async function safeText(resp) {
  try { return await resp.text(); } catch { return ""; }
}
