const express = require("express");
const path = require("path");
const fs = require("fs");
const fsp = require("fs/promises");

const app = express();
const PORT = process.env.PORT || 3030;

const DREAM_DIR = path.join(__dirname, "Dream Log");

function ensureDreamDirSync() {
    if (!fs.existsSync(DREAM_DIR)) fs.mkdirSync(DREAM_DIR, { recursive: true });
}

function isValidDateMMDDYYYY(s) {
    if (!/^\d{2}-\d{2}-\d{4}$/.test(s)) return false;
    const [mm, dd, yyyy] = s.split("-").map((v) => parseInt(v, 10));
    if (yyyy < 1900 || yyyy > 3000) return false;
    if (mm < 1 || mm > 12) return false;
    if (dd < 1 || dd > 31) return false;
    const d = new Date(yyyy, mm - 1, dd);
    return d.getFullYear() === yyyy && d.getMonth() === mm - 1 && d.getDate() === dd;
}

function toFilenameDate(mmddyyyy) {
    return mmddyyyy.replaceAll("-", "_");
}

function sanitizeDreamNameForFilename(name) {
    const trimmed = (name || "").trim();
    if (!trimmed) return "";
    return trimmed
        .replace(/[<>:"/\\|?*\x00-\x1F]/g, "")
        .replace(/\s+/g, "_")
        .replace(/\.+$/g, "")
        .slice(0, 120);
}

function safeResolveDreamPath(filename) {
    const full = path.join(DREAM_DIR, filename);
    const normalized = path.normalize(full);
    if (!normalized.startsWith(path.normalize(DREAM_DIR + path.sep))) {
        throw new Error("Invalid path.");
    }
    return normalized;
}

function formatDreamFile(dateMMDDYYYY, title, body) {
    return `[--------------DREAM LOG--------------]
--${dateMMDDYYYY}--
--${title}--

${body}

[-------------------------------------]
`;
}

ensureDreamDirSync();
app.use(express.json({ limit: "2mb" }));
app.use(express.static(path.join(__dirname, "public")));

app.get("/api/dreams", async (req, res) => {
    try {
        ensureDreamDirSync();
        const files = await fsp.readdir(DREAM_DIR);

        const dreams = files
            .filter((f) => f.toLowerCase().endsWith(".txt"))
            .map((filename) => {
                const base = filename.slice(0, -4);
                const parts = base.split("_");
                const mm = parts[0] || "00";
                const dd = parts[1] || "00";
                const yyyy = parts[2] || "0000";
                const titlePart = parts.slice(3).join("_");

                const displayDate = `${parseInt(mm, 10) || 0}/${parseInt(dd, 10) || 0}/${yyyy}`;
                const displayTitle = (titlePart || "").replaceAll("_", " ").trim() || "(Untitled)";
                const display = `${displayDate} - ${displayTitle}`;

                return { filename, display };
            })
            .sort((a, b) => {
                const pa = a.filename.replace(".txt", "").split("_");
                const pb = b.filename.replace(".txt", "").split("_");
                const keyA = `${pa[2] || ""}${pa[0] || ""}${pa[1] || ""}`;
                const keyB = `${pb[2] || ""}${pb[0] || ""}${pb[1] || ""}`;
                return keyB.localeCompare(keyA);
            });

        res.json({ dreams });
    } catch (err) {
        res.status(500).json({ error: err.message || "Failed to list dreams." });
    }
});

app.get("/api/dreams/:filename", async (req, res) => {
    try {
        const filename = req.params.filename;
        const fullPath = safeResolveDreamPath(filename);
        const text = await fsp.readFile(fullPath, "utf8");
        res.json({ filename, text });
    } catch (err) {
        res.status(400).json({ error: err.message || "Failed to load dream." });
    }
});

app.post("/api/dreams", async (req, res) => {
    try {
        ensureDreamDirSync();
        const { name, date, details } = req.body || {};

        if (!name || !date || !details) {
            return res.status(400).json({ error: "Missing name, date, or details." });
        }
        if (!isValidDateMMDDYYYY(date)) {
            return res.status(400).json({ error: "Date must be valid and formatted MM-DD-YYYY." });
        }

        const safeName = sanitizeDreamNameForFilename(name);
        if (!safeName) return res.status(400).json({ error: "Dream name is invalid/empty after sanitizing." });

        const fileDate = toFilenameDate(date);
        const filename = `${fileDate}_${safeName}.txt`;
        const fullPath = safeResolveDreamPath(filename);

        if (fs.existsSync(fullPath)) {
            return res.status(409).json({ error: "A dream with that date + name already exists." });
        }

        const content = formatDreamFile(date, name.trim(), String(details).trim());
        await fsp.writeFile(fullPath, content, "utf8");

        res.json({ ok: true, filename });
    } catch (err) {
        res.status(500).json({ error: err.message || "Failed to create dream." });
    }
});

app.post("/api/dreams/:filename/assessment", async (req, res) => {
    try {
        const filename = req.params.filename;
        const { date, assessment } = req.body || {};

        if (!assessment || !String(assessment).trim()) {
            return res.status(400).json({ error: "Assessment text is required." });
        }

        let dateLine = "";
        if (date && String(date).trim()) {
            const s = String(date).trim();
            if (!isValidDateMMDDYYYY(s)) {
                return res.status(400).json({ error: "Assessment date must be valid and formatted MM-DD-YYYY." });
            }
            dateLine = `--${s}--\n`;
        }

        const fullPath = safeResolveDreamPath(filename);

        const appendBlock =
            `\n\n[-----------DREAM ASSESSMENT----------]\n` +
            dateLine +
            `${String(assessment).trim()}\n`;

        await fsp.appendFile(fullPath, appendBlock, "utf8");
        res.json({ ok: true });
    } catch (err) {
        res.status(400).json({ error: err.message || "Failed to append assessment." });
    }
});

app.listen(PORT, () => {
    console.log(`Dream Journal running at http://localhost:${PORT}`);
    console.log(`Logs folder: ${DREAM_DIR}`);
});
