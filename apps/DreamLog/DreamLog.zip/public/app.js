let selectedFilename = null;

const el = (id) => document.getElementById(id);

function normalizeDateToMMDDYYYY(raw) {
    if (!raw) return "";

    const digits = String(raw).replace(/\D/g, "");

    if (digits.length === 8) {
        const mm = digits.slice(0, 2);
        const dd = digits.slice(2, 4);
        const yyyy = digits.slice(4, 8);
        return `${mm}-${dd}-${yyyy}`;
    }

    const parts = String(raw)
        .trim()
        .split(/[^0-9]+/)
        .filter(Boolean);

    if (parts.length < 3) return raw.trim();

    let [m, d, y] = parts;

    if (m.length === 1) m = "0" + m;
    if (d.length === 1) d = "0" + d;

    if (y.length === 2) y = "20" + y;

    const candidate = `${m}-${d}-${y}`;
    if (/^\d{2}-\d{2}-\d{4}$/.test(candidate)) return candidate;

    return raw.trim();
}

function attachAutoDateFormat(inputEl) {
    if (!inputEl) return;

    inputEl.addEventListener("input", () => {
        const v = inputEl.value;
        const digits = v.replace(/\D/g, "");

        if (digits.length >= 8) {
            inputEl.value = normalizeDateToMMDDYYYY(digits.slice(0, 8));
            return;
        }

        inputEl.value = v.replace(/[^\d\-\/\.\s]/g, "");
    });

    inputEl.addEventListener("blur", () => {
        inputEl.value = normalizeDateToMMDDYYYY(inputEl.value);
    });
}


function setTab(tabName) {
    const submitBtn = document.querySelector('.tab[data-tab="submit"]');
    const logBtn = document.querySelector('.tab[data-tab="log"]');
    const submitPanel = el("tab-submit");
    const logPanel = el("tab-log");

    const isSubmit = tabName === "submit";
    submitBtn.classList.toggle("active", isSubmit);
    logBtn.classList.toggle("active", !isSubmit);
    submitBtn.setAttribute("aria-selected", String(isSubmit));
    logBtn.setAttribute("aria-selected", String(!isSubmit));

    submitPanel.classList.toggle("active", isSubmit);
    logPanel.classList.toggle("active", !isSubmit);

    if (!isSubmit) refreshDreamList();
}

function status(target, msg, isError = false) {
    const node = el(target);
    node.textContent = msg || "";
    node.style.color = isError ? "rgba(255,92,134,.95)" : "rgba(255,255,255,.62)";
}

function validateDateMMDDYYYY(s) {
    return /^\d{2}-\d{2}-\d{4}$/.test(s);
}

async function refreshDreamList() {
    const list = el("dreamList");
    list.innerHTML = `<div class="status">Loading dreams…</div>`;

    try {
        const res = await fetch("/api/dreams");
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "Failed to list dreams.");

        list.innerHTML = "";
        if (!data.dreams.length) {
            list.innerHTML = `<div class="status">No dreams yet. Go write something weird.</div>`;
            return;
        }

        data.dreams.forEach((d) => {
            const item = document.createElement("div");
            item.className = "list-item";
            item.textContent = d.display;
            item.dataset.filename = d.filename;

            if (selectedFilename === d.filename) item.classList.add("active");

            item.addEventListener("click", async () => {
                document.querySelectorAll(".list-item").forEach((x) => x.classList.remove("active"));
                item.classList.add("active");
                await loadDream(d.filename, d.display);
            });

            list.appendChild(item);
        });
    } catch (err) {
        list.innerHTML = `<div class="status" style="color: rgba(255,92,134,.95)">Error: ${err.message}</div>`;
    }
}

async function loadDream(filename, displayTitle) {
    selectedFilename = filename;
    el("viewerTitle").textContent = displayTitle || "Dream";
    el("viewerFile").textContent = filename;

    el("copyDream").disabled = false;
    el("submitAssessment").disabled = false;
    status("assessStatus", "");

    try {
        const res = await fetch(`/api/dreams/${encodeURIComponent(filename)}`);
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "Failed to load dream.");
        el("dreamContent").textContent = data.text || "";
    } catch (err) {
        el("dreamContent").textContent = "";
        status("assessStatus", `Error loading dream: ${err.message}`, true);
    }
}

async function submitDream() {
    const name = el("dreamName").value.trim();
    const date = el("dreamDate").value.trim();
    const details = el("dreamDetails").value.trim();

    if (!name || !date || !details) {
        return status("submitStatus", "Fill out name, date, and details.", true);
    }
    if (!validateDateMMDDYYYY(date)) {
        return status("submitStatus", "Date must be MM-DD-YYYY (example: 01-29-2026).", true);
    }

    status("submitStatus", "Saving…");

    try {
        const res = await fetch("/api/dreams", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ name, date, details })
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "Failed to save dream.");

        status("submitStatus", "Saved. Your subconscious has been archived.");
        el("dreamDetails").value = "";

        setTab("log");
        await refreshDreamList();
    } catch (err) {
        status("submitStatus", err.message, true);
    }
}

async function submitAssessment() {
    if (!selectedFilename) return;

    const date = el("assessDate").value.trim();
    const assessment = el("assessText").value.trim();

    if (!assessment) {
        return status("assessStatus", "Write something in Assessment Notes.", true);
    }
    if (date && !validateDateMMDDYYYY(date)) {
        return status("assessStatus", "Assessment date must be MM-DD-YYYY.", true);
    }

    status("assessStatus", "Appending assessment…");

    try {
        const res = await fetch(`/api/dreams/${encodeURIComponent(selectedFilename)}/assessment`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ date, assessment })
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "Failed to append assessment.");

        status("assessStatus", "Appended. Reality remains optional.");
        el("assessText").value = "";

        const activeItem = document.querySelector(".list-item.active");
        await loadDream(selectedFilename, activeItem ? activeItem.textContent : "Dream");
    } catch (err) {
        status("assessStatus", err.message, true);
    }
}

async function copyDream() {
    const text = el("dreamContent").textContent || "";
    if (!text.trim()) return;

    try {
        await navigator.clipboard.writeText(text);
        const btn = el("copyDream");
        const old = btn.textContent;
        btn.textContent = "Copied!";
        setTimeout(() => (btn.textContent = old), 900);
    } catch {
        const ta = document.createElement("textarea");
        ta.value = text;
        document.body.appendChild(ta);
        ta.select();
        document.execCommand("copy");
        document.body.removeChild(ta);
        const btn = el("copyDream");
        const old = btn.textContent;
        btn.textContent = "Copied!";
        setTimeout(() => (btn.textContent = old), 900);
    }
}

document.querySelectorAll(".tab").forEach((t) => {
    t.addEventListener("click", () => setTab(t.dataset.tab));
});

el("submitDream").addEventListener("click", submitDream);
el("clearDream").addEventListener("click", () => {
    el("dreamName").value = "";
    el("dreamDate").value = "";
    el("dreamDetails").value = "";
    status("submitStatus", "");
});
el("refreshList").addEventListener("click", refreshDreamList);
el("submitAssessment").addEventListener("click", submitAssessment);
el("copyDream").addEventListener("click", copyDream);

attachAutoDateFormat(el("dreamDate"));
attachAutoDateFormat(el("assessDate"));

setTab("submit");
