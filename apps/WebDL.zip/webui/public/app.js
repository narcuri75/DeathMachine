const jobsEl = document.getElementById("jobs");
jobsEl.style.width = "100%";
const logEl = document.getElementById("log");
const metaEl = document.getElementById("meta");
const progressTextEl = document.getElementById("progressText");
const progressFillEl = document.getElementById("progressFill");
// const progressLineEl = document.getElementById("progressLine"); // not used anymore
const modeEl = document.getElementById("mode");
const runBtn = document.getElementById("run");
const stopBtn = document.getElementById("stop");
const addBtn = document.getElementById("add");
const toggleUrlsBtn = document.getElementById("toggleUrls");
const urlSectionEl = document.getElementById("urlSection");
const clearBtn = document.getElementById("clear");

let jobs = [];
const ADD_COUNT = 10;


function addJob(url = "", pl = "2", folder = "") {
    jobs.push({ url, pl, folder });
    render();
}
function removeJob(i) { jobs.splice(i, 1); render(); }

function render() {
    jobsEl.innerHTML = "";
    jobs.forEach((j, i) => {
        const div = document.createElement("div");
        div.className = "jobRow";

        // FORCE layout regardless of CSS
        div.style.width = "100%";
        div.style.display = "grid";
        div.style.boxSizing = "border-box";
        div.style.gridTemplateColumns = "minmax(0, 1fr) 200px 240px 44px"; // URL | dropdown | folder | X
        div.style.gap = "10px";
        div.style.alignItems = "center";
        div.style.marginTop = "10px";


        const url = document.createElement("input");
        url.style.width = "100%";
        url.style.minWidth = "0";
        url.className = "urlInput";
        url.placeholder = "Paste URL…";
        url.value = j.url;
        url.oninput = (e) => jobs[i].url = e.target.value;


        const folder = document.createElement("input");
        folder.style.width = "100%";
        folder.style.minWidth = "0";
        folder.className = "folderInput";
        folder.placeholder = "Folder (optional) e.g. Artist 1";
        folder.value = j.folder || "";
        folder.oninput = (e) => jobs[i].folder = e.target.value;


        const pl = document.createElement("select");
        pl.style.width = "100%";
        pl.style.minWidth = "0";

        pl.innerHTML = `<option value="1">Entire playlist</option><option value="2">Single track</option>`;
        pl.value = j.pl;
        pl.onchange = (e) => jobs[i].pl = e.target.value;

        const del = document.createElement("button");
        del.style.width = "44px";
        del.style.padding = "0";
        del.type = "button";
        del.className = "removeX danger";
        del.setAttribute("aria-label", "Remove this URL");
        del.textContent = "✕";
        del.onclick = () => removeJob(i);


        div.append(url, pl, folder, del);

        jobsEl.appendChild(div);
    });

    if (jobs.length === 0) {
        const hint = document.createElement("div");
        hint.className = "meta";
        hint.textContent = "Add at least one URL.";
        jobsEl.appendChild(hint);
    }
}

function appendLog(txt) {
    logEl.textContent += txt;
    logEl.scrollTop = logEl.scrollHeight;
}

let lastWholePercent = -1;
let carry = ""; // keep partial chunks between reads

function handleOutputChunk(raw) {
    // yt-dlp uses \r to "update the same line". We split on \r and \n.
    carry += raw;

    // Split into "events" using either CR or LF. Keep last partial in carry.
    const parts = carry.split(/\r|\n/);
    carry = parts.pop() || "";

    for (const p of parts) {
        processOnePiece(p);
    }
}

function processOnePiece(line) {
    const s = (line || "").trim();
    if (!s) return;

    // Detect yt-dlp progress line (works with overwrite style)
    // Example: [download]  69.2% of 1.25GiB at 1.24MiB/s ETA 05:17
    const m = s.match(/^\[download\]\s+(\d+(?:\.\d+)?)%/i);
    if (m) {
        const pct = Math.floor(parseFloat(m[1]));
        if (pct !== lastWholePercent) {
            lastWholePercent = pct;
            progressFillEl.style.width = `${pct}%`;

            // Optional: include speed/ETA if present, but no spam.
            const sm = s.match(/\bat\s+([0-9.]+\w+\/s)\b/i);
            const em = s.match(/\bETA\s+(\S+)\b/i);
            const speed = sm ? sm[1] : "";
            const eta = em ? em[1] : "";

            let extra = "";
            if (speed) extra += ` | ${speed}`;
            if (eta) extra += ` | ETA ${eta}`;

            progressTextEl.textContent = `Progress: ${pct}%${extra}`;
        }
        return; // IMPORTANT: do NOT append progress spam to log
    }

    // Not a progress line → normal log
    appendLog(s + "\n");
}


// Track whole-number progress so we only update when % changes


addBtn.onclick = () => {
    for (let i = 0; i < ADD_COUNT; i++) addJob("", "2");
};

let urlsCollapsed = false;

toggleUrlsBtn.onclick = () => {
    urlsCollapsed = !urlsCollapsed;
    urlSectionEl.classList.toggle("hidden", urlsCollapsed);
    toggleUrlsBtn.textContent = urlsCollapsed ? "Show URLs" : "Collapse URLs";
};


clearBtn.onclick = () => { logEl.textContent = ""; metaEl.textContent = ""; };

runBtn.onclick = async () => {
    const payload = {
        mode: modeEl.value,
        jobs: jobs.map(j => ({ url: j.url.trim(), pl: j.pl, folder: (j.folder || "").trim() })).filter(j => j.url.length > 0)
    };

    if (payload.jobs.length === 0) return appendLog("No URLs.\n");

    runBtn.disabled = true;
    stopBtn.disabled = false;
    appendLog(`\n=== Starting (${modeEl.options[modeEl.selectedIndex].text}) ===\n`);

    lastWholePercent = -1;
    carry = "";
    progressFillEl.style.width = "0%";
    progressTextEl.textContent = "Progress: —";

    const es = new SSEClient("/api/run", payload);
    es.on("meta", (d) => metaEl.textContent = `Log file: ${d.logFile}`);
    es.on("out", (d) => {
        handleOutputChunk(d.text || "");
    });

    es.on("err", (d) => {
        handleOutputChunk(d.text || "");
    });


    es.on("done", (d) => {
        appendLog(`\n=== Done (exit ${d.code}) ===\n`);
        runBtn.disabled = false;
        stopBtn.disabled = true;
        progressTextEl.textContent = "Progress: complete";
        progressFillEl.style.width = "100%";
        es.close();
    });
};

stopBtn.onclick = async () => {
    await fetch("/api/stop", { method: "POST" });
    appendLog("\n=== Stop requested ===\n");
};

class SSEClient {
    constructor(url, body) {
        this.url = url;
        this.body = body;
        this.handlers = {};
        this.controller = new AbortController();
        this.start();
    }
    on(type, fn) { this.handlers[type] = fn; }
    close() { this.controller.abort(); }

    async start() {
        const resp = await fetch(this.url, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(this.body),
            signal: this.controller.signal
        });

        const reader = resp.body.getReader();
        const dec = new TextDecoder("utf-8");
        let buf = "";

        while (true) {
            const { value, done } = await reader.read();
            if (done) break;
            buf += dec.decode(value, { stream: true });

            let idx;
            while ((idx = buf.indexOf("\n\n")) !== -1) {
                const chunk = buf.slice(0, idx);
                buf = buf.slice(idx + 2);

                let event = "message";
                let data = "";
                for (const line of chunk.split("\n")) {
                    if (line.startsWith("event:")) event = line.slice(6).trim();
                    if (line.startsWith("data:")) data += line.slice(5).trim();
                }

                const fn = this.handlers[event];
                if (fn) {
                    try { fn(JSON.parse(data)); }
                    catch { fn({ text: data }); }
                }
            }
        }
    }
}

addJob();
