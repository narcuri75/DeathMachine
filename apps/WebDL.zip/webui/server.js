const express = require("express");
const path = require("path");
const fs = require("fs");
const os = require("os");
const { spawn } = require("child_process");

const app = express();
app.use(express.json({ limit: "2mb" }));
app.use(express.static(path.join(__dirname, "public")));

const ROOT = path.resolve(__dirname, "..");              // folder with yt-dlp.exe + .bat
const BAT = path.join(ROOT, "ytdlp_menu.bat");          // <-- must match your bat filename
const OUTDIR = path.join(ROOT, "output");
if (!fs.existsSync(OUTDIR)) fs.mkdirSync(OUTDIR, { recursive: true });

let currentProc = null;

app.get("/api/status", (req, res) => res.json({ running: !!currentProc }));

function cleanFolderName(name) {
    name = String(name || "").trim();
    if (!name) return "";

    // remove invalid Windows folder chars
    name = name.replace(/[<>:"/\\|?*\x00-\x1F]/g, "_");

    // prevent path traversal
    name = name.replace(/\.\./g, "_");

    // Windows hates trailing dots/spaces
    name = name.replace(/[. ]+$/g, "");

    return name;
}


app.post("/api/run", (req, res) => {
    if (currentProc) return res.status(409).json({ error: "Already running." });

    const { mode, jobs } = req.body;
    if (!["1", "2", "3"].includes(String(mode))) return res.status(400).json({ error: "Bad mode." });
    if (!Array.isArray(jobs) || jobs.length === 0) return res.status(400).json({ error: "No jobs." });

    const jobFile = path.join(os.tmpdir(), `yt_dlp_jobs_web_${Date.now()}_${Math.random().toString(16).slice(2)}.txt`);
    const logFile = path.join(OUTDIR, "yt-dlp_webui.log");
    const urlFiles = [];

    try {
        const lines = [];
        for (const j of jobs) {
            const url = String(j.url || "").trim();
            const pl = String(j.pl || "").trim();
            if (!url) continue;
            if (pl !== "1" && pl !== "2") continue;

            const urlFile = path.join(os.tmpdir(), `yt_dlp_url_web_${Date.now()}_${Math.random().toString(16).slice(2)}.txt`);
            fs.writeFileSync(urlFile, url, "utf8");
            urlFiles.push(urlFile);
            const folder = cleanFolderName(j.folder);
            lines.push(`${pl}#${urlFile}#${folder}`);

        }

        if (lines.length === 0) return res.status(400).json({ error: "No valid jobs after validation." });
        fs.writeFileSync(jobFile, lines.join("\r\n") + "\r\n", "utf8");
    } catch (e) {
        for (const f of urlFiles) { try { fs.unlinkSync(f); } catch { } }
        try { fs.unlinkSync(jobFile); } catch { }
        return res.status(500).json({ error: "Failed to build job files.", detail: String(e) });
    }

    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache");
    res.setHeader("Connection", "keep-alive");

    const send = (type, data) => {
        res.write(`event: ${type}\n`);
        res.write(`data: ${JSON.stringify(data)}\n\n`);
    };

    send("meta", { logFile });

    const args = ["--mode", String(mode), "--jobs", jobFile, "--log", logFile];

    currentProc = spawn("cmd.exe", ["/c", BAT, ...args], { cwd: ROOT, windowsHide: true });

    function scrubNoise(s) {
        return s.replace(/ERROR: Input redirection is not supported, exiting the process immediately\.\r?\n?/g, "");
    }

    currentProc.stdout.on("data", (b) => {
        const text = scrubNoise(b.toString("utf8"));
        if (text.trim().length) send("out", { text });
    });

    currentProc.stderr.on("data", (b) => {
        const text = scrubNoise(b.toString("utf8"));
        if (text.trim().length) send("err", { text });
    });


    currentProc.on("close", (code) => {
        send("done", { code });

        try { fs.unlinkSync(jobFile); } catch { }
        for (const f of urlFiles) { try { fs.unlinkSync(f); } catch { } }

        currentProc = null;
        res.end();
    });
});

app.post("/api/stop", (req, res) => {
    if (!currentProc) return res.json({ stopped: false });

    // Kill the whole process tree on Windows (cmd -> bat -> yt-dlp)
    try {
        spawn("taskkill", ["/PID", String(currentProc.pid), "/T", "/F"], { windowsHide: true });
    } catch {
        // fallback
        try { currentProc.kill("SIGTERM"); } catch { }
    }

    res.json({ stopped: true });
});


const PORT = 8787;
app.listen(PORT, () => console.log(`WebUI: http://localhost:${PORT}`));
