const jobsEl = document.getElementById("jobs");
const logEl = document.getElementById("log");
const metaEl = document.getElementById("meta");
const progressTextEl = document.getElementById("progressText");
const progressFillEl = document.getElementById("progressFill");

const modeEl = document.getElementById("mode");
const runBtn = document.getElementById("run");
const stopBtn = document.getElementById("stop");
const addBtn = document.getElementById("add");
const clearUrlsBtn = document.getElementById("clearUrls");
const batchBar = document.getElementById("batchBar");
const batchCountEl = document.getElementById("batchCount");
const batchFolderEl = document.getElementById("batchFolder");
const batchApplyBtn = document.getElementById("batchApply");
const batchSelectAllEl = document.getElementById("batchSelectAll");
const batchClearSelBtn = document.getElementById("batchClearSel");
const clearLogBtn = document.getElementById("clearLog");
const toggleUrlsBtn = document.getElementById("toggleUrls");
const urlSectionEl = document.getElementById("urlSection");
const serverBadge = document.getElementById("serverBadge");

let state = null;

// Live updates while popup is open
const port = chrome.runtime.connect({ name: "popup" });
port.onMessage.addListener((msg) => {
  if (msg?.type === "state") {
    state = msg.state;
    render();
  }
});

function send(type, payload = {}) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage({ type, ...payload }, (resp) => resolve(resp));
  });
}

async function init() {
  const resp = await send("getState");
  state = resp?.state || null;
  render();
  await refreshServerBadge();
  setInterval(refreshServerBadge, 2000);
}

async function refreshServerBadge() {
  const r = await send("status");
  const st = r?.status;

  if (!st?.online) {
    serverBadge.textContent = "Server: offline";
    serverBadge.classList.remove("ok");
    serverBadge.classList.add("bad");
    return;
  }

  serverBadge.textContent = st.running ? "Server: running" : "Server: online";
  serverBadge.classList.remove("bad");
  serverBadge.classList.add("ok");
}

function render() {
  if (!state) return;

  // Mode
  modeEl.value = String(state.mode || "1");

  // URL collapse
  const collapsed = !!state.urlsCollapsed;
  urlSectionEl.classList.toggle("hidden", collapsed);
  toggleUrlsBtn.textContent = collapsed ? "Show URLs" : "Collapse URLs";

  // Buttons state
  const running = !!state.running;
  runBtn.disabled = running;
  stopBtn.disabled = !running;

  // Progress
  const pct = Number(state.progressPercent || 0);
  progressFillEl.style.width = `${Math.min(Math.max(pct, 0), 100)}%`;
  progressTextEl.textContent = state.progressText || "Progress: —";

  // Log + meta
  logEl.textContent = state.log || "";
  metaEl.textContent = state.meta || "";

  // Jobs
  jobsEl.innerHTML = "";
  const jobs = Array.isArray(state.jobs) ? state.jobs : [];

  const selectedCount = jobs.reduce((n, j) => n + (j && j.selected ? 1 : 0), 0);
  batchBar.classList.toggle("hidden", selectedCount === 0);
  batchCountEl.textContent = String(selectedCount);
  // Keep "Select all" in sync when batch bar is visible
  if (selectedCount > 0) {
    batchSelectAllEl.checked = selectedCount === jobs.length;
    batchSelectAllEl.indeterminate = selectedCount > 0 && selectedCount < jobs.length;
  } else {
    batchSelectAllEl.checked = false;
    batchSelectAllEl.indeterminate = false;
  }

  jobs.forEach((j, i) => {
    const div = document.createElement("div");
    div.className = "jobRow";

    const sel = document.createElement("input");
    sel.type = "checkbox";
    sel.className = "selectBox";
    sel.checked = !!j.selected;
    sel.onchange = (e) => {
      send("updateJob", { index: i, patch: { selected: e.target.checked } });
    };

    const url = document.createElement("input");
    url.className = "urlInput";
    url.placeholder = "Paste URL…";
    url.value = j.url || "";
    url.oninput = (e) => {
      // update on each keystroke, but cheap enough for local
      send("updateJob", { index: i, patch: { url: e.target.value } });
    };

    const pl = document.createElement("select");
    pl.innerHTML = `<option value="1">Entire playlist</option><option value="2">Single track</option>`;
    pl.value = (String(j.pl) === "1") ? "1" : "2";
    pl.onchange = (e) => {
      send("updateJob", { index: i, patch: { pl: e.target.value } });
    };

    const folder = document.createElement("input");
    folder.className = "folderInput";
    folder.placeholder = "Folder (optional) e.g. Artist 1";
    folder.value = j.folder || "";
    folder.oninput = (e) => {
      send("updateJob", { index: i, patch: { folder: e.target.value } });
    };

    const del = document.createElement("button");
    del.type = "button";
    del.className = "removeX danger";
    del.setAttribute("aria-label", "Remove this URL");
    del.textContent = "✕";
    del.onclick = () => send("removeJob", { index: i });

    div.append(sel, url, pl, folder, del);
    jobsEl.appendChild(div);
  });

  if (jobs.length === 0) {
    const hint = document.createElement("div");
    hint.className = "meta";
    hint.textContent = "Add at least one URL. (Or right-click a link/selection on any page.)";
    jobsEl.appendChild(hint);
  }
}

modeEl.addEventListener("change", (e) => send("setMode", { mode: e.target.value }));

toggleUrlsBtn.addEventListener("click", () => send("toggleUrls"));

addBtn.addEventListener("click", () => send("addJob", { url: "", pl: "2", folder: "", allowEmpty: true }));

clearUrlsBtn.addEventListener("click", () => send("clearJobs"));

clearLogBtn.addEventListener("click", () => send("clearLog"));


batchApplyBtn.addEventListener("click", async () => {
  if (!state) return;
  const folder = String(batchFolderEl.value || "");
  const jobs = Array.isArray(state.jobs) ? state.jobs : [];
  const idxs = [];
  jobs.forEach((j, i) => { if (j && j.selected) idxs.push(i); });
  for (const i of idxs) {
    await send("updateJob", { index: i, patch: { folder } });
  }
});

batchSelectAllEl.addEventListener("change", async (e) => {
  if (!state) return;
  const checked = !!e.target.checked;
  const jobs = Array.isArray(state.jobs) ? state.jobs : [];
  // Only meaningful when batch bar is visible, but harmless otherwise.
  for (let i = 0; i < jobs.length; i++) {
    await send("updateJob", { index: i, patch: { selected: checked } });
  }
});

batchClearSelBtn.addEventListener("click", async () => {
  if (!state) return;
  const jobs = Array.isArray(state.jobs) ? state.jobs : [];
  for (let i = 0; i < jobs.length; i++) {
    if (jobs[i]?.selected) {
      await send("updateJob", { index: i, patch: { selected: false } });
    }
  }
});


runBtn.addEventListener("click", async () => {
  const r = await send("run");
  if (!r?.ok) {
    // Show an inline error in the log so it persists.
    await send("updateJob", { index: -1, patch: {} });
    await send("clearLog"); // keep it simple: clear + error line
    const msg = r?.error || "Failed to start";
    // Append error by calling run again? No. Just write into log by asking background to patch.
    chrome.runtime.sendMessage({
      type: "_patchLog",
      text: `\n=== ERROR ===\n${msg}\n`
    });
  }
});

stopBtn.addEventListener("click", () => send("stop"));

// Patch log helper (kept as a private backdoor so we don't overcomplicate message schema)
chrome.runtime.onMessage.addListener((msg) => {
  // no-op in popup
});

init();
