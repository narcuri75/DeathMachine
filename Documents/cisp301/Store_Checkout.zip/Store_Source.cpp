// Created by Nathan Arcuri
// 7/28/2021
// This program will prompt the user for item Cost in their shopping bag and store them in a text file called "PurchaseData.txt".
// It will output the Cost of each item, add them together and output the total cost of all items, the least expensive item, the most expensive item, and the average cost of all items.

#include <iostream>
#include <fstream>
#include <string>
#include <iomanip>
using namespace std;

fstream PurchaseData;
float TotalCost = 0;
float Least = 1000;
float Most = 0;
float Avg = 0;
int Count = 1;

void Input();
void Output();

int main()
{
	char Choice = 'a';
	cout << "***** Welcome to ABC store *****" << endl;
	cout << "Do you have an item to scan? (Y)es/(N)o?" << endl;
	cin >> Choice;
	if (Choice == 'y' || Choice == 'Y')
	{
		Input();
		Output();
	}
	if (Choice == 'n' || Choice == 'N')
	{
		cout << "Thanks for shopping at the ABC store!";
	}
	return 0;
}

void Input()
{
	float Cost;
	PurchaseData.open("PurchaseData.txt", ios::out);
	cout << "Enter the price for item #" << Count << " or enter -1 to generate final invoice: ";
	cin >> Cost;
	while (Cost != -1)
	{
		PurchaseData << "Item #" << Count << ": ***** $" << Cost << endl;
		TotalCost = TotalCost + Cost;
		if (Cost < Least)
		{
			Least = Cost;
		}
		if (Cost > Most)
		{
			Most = Cost;
		}
		Count = Count + 1;
		cout << "Enter the price for item #" << Count << " or enter -1 to generate final invoice: ";
		cin >> Cost;
	}
	Count = Count - 1;
	Avg = TotalCost / Count;
	PurchaseData << "Your bag contains a total of " << Count << " items." << endl;
	PurchaseData << "Grand total for this purchase: $" << fixed << setprecision(2) << TotalCost << endl;
	PurchaseData << "Least expensive item in your bag: $" << fixed << setprecision(2) << Least << endl;
	PurchaseData << "Most expensive item in your bag: $" << fixed << setprecision(2) << Most << endl;
	PurchaseData << "Average item cost: $" << fixed << setprecision(2) << Avg << endl;
	PurchaseData.close();
}

void Output()
{
	cout << endl
		 << "***** Welcome to ABC store *****" << endl;
	cout << "***** Here are the details of your purchase *****" << endl;
	PurchaseData.open("PurchaseData.txt", ios::in);
	string record;
	while (!PurchaseData.eof())
	{
		getline(PurchaseData, record);
		cout << record << endl;
	}
	PurchaseData.close();
	cout << "***** Thanks for shopping at the ABC store! *****" << endl;
}